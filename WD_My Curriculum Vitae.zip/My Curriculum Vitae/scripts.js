//per far caricare tutto il DOM prima che venga eseguito il codice JS
document.addEventListener("DOMContentLoaded", () => {

    //HOME PAGE

    //creo due costanti per il bottone menu (desktop)
    const menuToggle = document.querySelector(".menuButtonDesktop");
    //e per il menu a tendina che deve comparire quando si clicca il bottone menu
    const menuButtonDesktop = document.querySelector(".sottoMenuDesktop");

    //se la costante per il bottone menu esiste, allora, con l'evento click, mostra la classe show del menu a tendina
    if (menuToggle) {
        menuToggle.addEventListener("click", () => {
            menuButtonDesktop.classList.toggle("show");
        });
    }

    //creo due costanti per il bottone hamburger (mobile)
    const menuMobileToggle = document.querySelector(".hamburger");
    //e per il menu a tendina che deve comparire quando si clicca il bottone hamburger
    const hamburger = document.querySelector(".sottoMenuMobile");

    //se la costante per il bottone hamburger esiste, allora, con l'evento click, mostra la classe show del menu a tendina
    if (menuMobileToggle) {
        menuMobileToggle.addEventListener("click", () => {
            hamburger.classList.toggle("show");
        });
    }

    //CONTACT FORM

    // Reset degli eventuali errori dopo il click del bottone reset nel Contact Form
    if (resetButton) {
        resetButton.addEventListener("click", function (event) {
        document.getElementById("fullNameError").textContent = "";
        document.getElementById("emailError").textContent = "";
        document.getElementById("messageError").textContent = "";   
        });
    }

    // Gestione del submit del form durante l'evento click
    const submitButton = document.getElementById("submitButton");

    if (submitButton) {
        submitButton.addEventListener("click", function (event) {
            event.preventDefault();

        // Reset degli errori dei submit precedenti
        document.getElementById("fullNameError").textContent = "";
        document.getElementById("emailError").textContent = "";
        document.getElementById("messageError").textContent = "";

        //inizializzazione della variabile isValid
        let isValid = true;

        //check del nome che non può essere inferiore a 2 caratteri alfabetici
        const fullName = document.getElementById("fullName").value;
        const checkName = /^(?=(.*[a-zA-Z]){2,})[a-zA-Z\s]+$/;
        if (!fullName || !checkName.test(fullName)) {
            document.getElementById("fullNameError").textContent = "Insert your name.";
            isValid = false;
        }

        //check dell'email che deve rispettare il pattern
        const email = document.getElementById("email").value;
        const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        if (!email || !emailPattern.test(email)) {
            document.getElementById("emailError").textContent = "Insert a valid email.";
            isValid = false;
        }

        //check del messaggio che non può essere vuoto
        const message = document.getElementById("message").value;
        if (message === "") {
            document.getElementById("messageError").textContent = "Type a message.";
            isValid = false;
        }

        //se i campi sono validi, compare il popup di avvenuto submit
        if (isValid) {
            document.getElementById("popup").classList.remove("cfHiddenPopup");
            document.getElementById("popup").classList.add("cfShowPopup");

            //dopo 5 secondi (5000 ms) viene resettato il form e scompare il popup di avvenuto submit
            setTimeout(() => {
                document.getElementById("popup").classList.remove("cfShowPopup");
                document.getElementById("popup").classList.add("cfHiddenPopup");
                contactForm.reset();
            }, 5000);
        }
    });
}
});
